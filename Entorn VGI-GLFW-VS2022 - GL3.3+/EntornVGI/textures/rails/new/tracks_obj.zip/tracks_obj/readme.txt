rail_straight: 20.25m, connection points (0,0,-10.125); (0,0,10.125)
rail_switch_left: 18 deg, connection points (0,0,-10.125); (0,0,10.125); (-2.209, 0, -10.061)
rail_switch_right: 18 deg, connection points (0,0,-10.125); (0,0,10.125); (2.209, 0, -10.061)
rail_turn_left: 18 deg, connection points (-2.209, 0, -10.061); (0,0,10.125);
rail_turn_right 18 deg, connection points (2.209, 0, -10.061); (0,0,10.125); 
